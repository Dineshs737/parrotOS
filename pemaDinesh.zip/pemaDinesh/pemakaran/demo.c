#include<stdio.h>
#include"./MedicineFunction.h"
//#include"./userHistory.h"

int main(){
    //StoreMedicine();
    //StoreSuggestion("pema");
    fileLoadUpMedicine();
}