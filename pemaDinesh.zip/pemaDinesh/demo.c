#include<stdio.h>
//#include"./admin.h"
//#include"./pecint.h"
//#include"./MedicineLog.h"
//#include"./userHistory.h"
#include"./medicineData.h"

// void medicineLogin(){
//     int op;
//      printf("\n\t\t\t== == == == == == == == == == == == == == == == == == ==\n");
//      printf("\n\t\t\t\t\t[1]. Add new Medicine\n");
//      printf("\t\t\t\t\t[2]. Display Medicine Detail\n");
//      printf("\t\t\t\t\t[3]. Update Medicine Detail\n");
//      printf("\t\t\t\t\t[4]. Exit\n");
//      printf("\n\t\t\t== == == == == == == == == == == == == == == == == == ==\n");

//     printf("\t\t\t _______________________________________________________\n");
//     printf("\t\t\t\t\t    Eenter Your choice :");
//     scanf("%d",op);
//     printf("\t\t\t _______________________________________________________\n");
//     StoreMedicine();
//     /*switch(op){
//         case 1 :StoreMedicine(); break;
//         case 2 :adminMedicine();break;
//         case 3 :MedicineUpdate();break;
//     }*/
// }

int main(int argc, char const *argv[])
{
  
  
//StoreMedicine();
//MedicineUpdate();
//fileLoadUpMedicine();
//StoreMedicine();
//fileLoadUpTreartment();
//StoreTreartment("dinesh" ,"pema");
//DoctorTreartment("dinesh");
//adminTreartment();
//char name[200]="pema";
 //DoctorTreartment(name);
 //patientTreartment("pema");
// StoreSuggestion("dinesh");
 //adminSuggestion();
 //DoctorSuggestion("dinesh");    
 medicineLogin();
  //StoreMedicine();
    return 0;
}
