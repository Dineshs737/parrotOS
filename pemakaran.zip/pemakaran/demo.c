#include<stdio.h>
#include"./TreartmentFunction.h"
#include"./userHistory.h"

int main(){
    StoreTreartment();
}